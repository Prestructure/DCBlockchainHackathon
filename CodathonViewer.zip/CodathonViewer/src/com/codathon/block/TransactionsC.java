package com.codathon.block;

import com.codathon.objects.Transaction;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TransactionsC {
    
    public static List<Transaction> list() {
        List<Transaction> transactions = new ArrayList();

        String result = ShellCommand.getTransactions();

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        Transaction[] objects;
        try {
            objects = (Transaction[]) mapper.readValue(result, Transaction[].class);

            transactions.addAll(Arrays.asList(objects));
        } catch (IOException ex) {
            ex.printStackTrace();
            objects = null;
        }

        return transactions;
    }
    
}
