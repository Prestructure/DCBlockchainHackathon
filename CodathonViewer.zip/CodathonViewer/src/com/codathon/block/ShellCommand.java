package com.codathon.block;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author tecnit
 */
public class ShellCommand {

    private static String executeCommand(String command) {
        StringBuilder output = new StringBuilder();

        Process p;
        try {
            p = Runtime.getRuntime().exec(command);
            p.waitFor();

            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        return output.toString();
    }
    
    public static String getTransactions() {
        String command = "zcash-cli z_listreceivedbyaddress ztRC3jTaN5iVJXZG9rDZMGTCuHTKTwqRdAmm5L74CXFiaiZrsJyX1fVRiFUbDBzyqHTNjgoa3gqkRmZfqUGRu2T2jAptsZW";
        
        String output = ShellCommand.executeCommand(command);

        return output;
    }

    public static void main(String[] args) {
        String command = "zcash-cli z_listreceivedbyaddress ztRC3jTaN5iVJXZG9rDZMGTCuHTKTwqRdAmm5L74CXFiaiZrsJyX1fVRiFUbDBzyqHTNjgoa3gqkRmZfqUGRu2T2jAptsZW";
        
        String output = ShellCommand.executeCommand(command);

        System.out.println(output);
    }

}
