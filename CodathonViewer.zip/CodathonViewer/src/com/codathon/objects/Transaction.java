package com.codathon.objects;

import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;

/**
 *
 * @author tecnit
 */
public class Transaction {
    
    private String txid;
    private String amount;
    private String memo;

    public String getTxid() {
        return txid;
    }

    public void setTxid(String txid) {
        this.txid = txid;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        byte[] bytes = null;
        try {
            bytes = Hex.decodeHex(memo.toCharArray());
            this.memo = new String(bytes, "UTF-8");
        } catch (DecoderException | UnsupportedEncodingException ex) {
            ex.printStackTrace();
        }
        
        /*StringBuilder sbMemo = new StringBuilder(memo);
        
        for (int i = sbMemo.length() - 1; i >= 0; i--) {
            if (sbMemo.charAt(i) == '0') {
                sbMemo.deleteCharAt(i);
            }
        }
        
        this.memo = sbMemo.toString();*/
    }
    
}
