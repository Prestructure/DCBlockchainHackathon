package com.codathon.objects;

/**
 *
 * @author tecnit
 */
public class Policy {
    
}
