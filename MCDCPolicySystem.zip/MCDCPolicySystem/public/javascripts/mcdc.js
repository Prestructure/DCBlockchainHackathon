'use strict';

var app = angular.module( 'votr', ['ngResource', 'ngRoute', 'ui.bootstrap.datetimepicker', 'angularFileUpload'] );

app.config( function( $routeProvider ) {
    $routeProvider
        .when( '/', {templateUrl: 'index.html' } )
        .when( '/login', {templateUrl: 'login.html', controller: 'LoginCtrl'} )
        .when( '/logout', {templateUrl: 'login.html', controller: 'LogoutCtrl'} )
        .when( '/policies', {templateUrl: './policies/list.html', controller: 'PoliciesController'} )
        .otherwise( {redirectTo: '/'} );
} );

app.config( function( $httpProvider ) {
    $httpProvider.interceptors.push( function( $rootScope, $location, $q ) {
        return {
            'request': function( request ) {
                // if we're not logged-in to the AngularJS app, redirect to login page
                $rootScope.loggedIn = $rootScope.loggedIn || $rootScope.username;
                if( !$rootScope.loggedIn && $location.path() != '/login' ) {
                    $location.path( '/login' );
                }
                return request;
            },
            'responseError': function( rejection ) {
                // if we're not logged-in to the web service, redirect to login page
                if( rejection.status === 401 && $location.path() != '/login' ) {
                    $rootScope.loggedIn = false;
                    $location.path( '/login' );
                }
                return $q.reject( rejection );
            }
        };
    } );
} );

app.factory( 'PoliciesService', function( $resource ) {
    return $resource( '/api/policies/:id', null, {
        'generate': { method: 'PUT' }
    } );
} );

app.factory( 'SessionService', function( $resource ) {
    return $resource( '/api/sessions' );
} );

app.controller( 'LoginCtrl', function( $scope, $rootScope, $location, SessionService ) {
    $scope.user = { username: '', password: '', remember: false };

    $scope.login = function() {
        $scope.user = SessionService.save( $scope.user, function( success ) {
            $rootScope.loggedIn = true;
            $location.path( '/policies' );
        }, function( error ) {
            $scope.loginError = true;
            $scope.user.password = '';
        } );
    };
} );

app.controller( 'LogoutCtrl', function( $rootScope, $location, SessionService ) {
    (new SessionService()).$delete( function( success ) {
        $rootScope.loggedIn = false;
        $location.path( '/login' );
    } );
} );

app.controller( 'PoliciesController', function( $scope, $location, $timeout, PoliciesService ) {
    var datatable = undefined;
    $scope.recipients = [];
    $scope.effects = [
        { value: "ALLOW", label: "ALLOW" },
        { value: "DENY", label: "DENY" }
    ];
    $scope.actions = [
        { value: "sendRecord", label: "sendRecord" },
        { value: "receiveRecord", label: "receiveRecord" },
        { value: "deleteRecord", label: "deleteRecord" },
        { value: "storeRecord", label: "storeRecord" },
        { value: "copyRecord", label: "copyRecord" }
    ];

    PoliciesService.query( function( policies ) {
        $scope.policies = policies;
    } );

    $scope.refresh = function() {
        if( datatable != undefined )
            datatable.fnDestroy();
        $timeout( function() {
            datatable = $( '#tablePolicies' ).dataTable( {
                "destroy": true,
                "bStateSave": true
            } );
        } );
    };

    $scope.$watchCollection( 'policies', function( oldCollection, newCollection ) {
        if( oldCollection === newCollection ) return;
        $scope.refresh();
    } );

    $scope.addNewChoice = function(){
        $scope.recipients.push( { recipient: "" } );
    };

    $scope.removeChoice = function(){
        var lastItem = $scope.entity.recipients.length - 1;
        $scope.recipients.splice( lastItem );
    };

    $scope.edit = function( policy ) {
        if( policy === 'new' ) {
            $scope.isNew = true;
            $scope.entity = { effect: '', action: '', patientId: 0, type: '', provider: '', expiration: '', recipients: [], entity: 'policy' };
            $scope.recipients = [{ recipient: "" }];
        } else {
            $scope.isNew = false;
            $scope.entity = policy;
            $scope.recipients = [];
            for( var i = 0; i < $scope.entity.recipients.length; i++ ){
                $scope.recipients.push({ recipient: $scope.entity.recipients[i] });
            }
        }
    }

    $scope.persist = function() {
        $scope.entity.recipients = [];
        for( var i = 0; i < $scope.recipients.length; i++ ){
            $scope.entity.recipients.push( $scope.recipients[i].recipient );
        }

        if( !$scope.entity._id ) {
            var newPolicy = new PoliciesService( $scope.entity );
            newPolicy.$save( function() {
                $scope.policies.push( newPolicy );
            } );
        } else {
            $scope.policies.forEach( function( e ) {
                if( e._id === $scope.entity._id ) {
                    e.$save();
                    $scope.refresh();
                }
            } );
        }
    };

    $scope.remove = function() {
        $scope.policies.forEach( function( e, index ) {
            if( e._id == $scope.entity._id ) {
                $scope.entity.$delete( {id: $scope.entity._id, rev: $scope.entity._rev}, function() {
                    $scope.policies.splice( index, 1 );
                } );
            }
        } );
    };

} );
