/**
 * Module dependencies.
 */

var express    = require( 'express' )
  , http       = require( 'http' )
  , php        = require( 'node-php' )
  , path       = require( 'path' )
  , config     = require( './config' );

var app        = express()
  , server     = http.createServer( app );

app.configure( function() {
    //app.enable( 'view cache' );
    app.engine( 'hjs', require('hogan-express'));
    app.set( 'port', process.env.PORT || 80 );
    app.set( 'views', __dirname + '/views' );
    app.set( 'view engine', 'hjs' );
    app.set( 'partials', { topbar: __dirname + '/views/topbar',
                           navbar: __dirname + '/views/navbar' } );
    app.use( express.favicon() );
    app.use( express.logger( 'dev' ) );
    app.use( express.bodyParser() );
    app.use( express.methodOverride() );
    app.use( express.cookieParser( config.cookiesecret ) );
    app.use( app.router );
    app.use( express.static( path.join( __dirname, 'public' ) ) );
    //
} );

app.configure( 'development', function() {
    app.use( express.errorHandler() );
} );

app.use( "/blog/", php.cgi( __dirname + '/php/wordpress' ) );

server.listen( app.get( 'port' ), function() {
    console.log( "Express server listening on port " + app.get( 'port' ) );
} );

var general = require( './routes/general' );
var policies = require( './routes/policies' );

// ADMIN PANEL
app.get( '/admin/', function( req, res ) {
    if( process.env.NODE_ENV === 'production' && req.headers['x-forwarded-proto'] !== 'https' ) {
        return res.redirect( 'https://' + req.get( 'Host' ) + req.url );
    } else {
        general.admin( req, res );
    }
} );

app.get('/', function(req, res) {
    return res.redirect( 'http://' + req.get( 'Host' ) + '/admin' );
});

// REST API

app.post   ( '/api/sessions',   general.login );
app.delete ( '/api/sessions',   general.logout );

app.get    ( '/api/policies',     policies.list );
app.get    ( '/api/policies/:id', policies.findById );
app.get    ( '/api/policies/GetPoliciesForUser/:id', policies.findById );
app.delete ( '/api/policies/:id', policies.remove );
app.post   ( '/api/policies/UpdatePolicy',     policies.persist );
app.post   ( '/api/policies',     policies.persist );
