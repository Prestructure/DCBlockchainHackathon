var config = require( '../config' )
    , dao = require( '../models/dao' )( 'policy' ),
      fs = require( 'fs' );

exports.findById = function( req, res ) {
    dao.query( 'find', {keys: [parseInt(req.params.id)], reduce: false}, function( err, stand ) {
        if( err ) {
            console.log("error: " + err);
            res.send( JSON.stringify( [] ) );
        } else {
            res.send( JSON.stringify( stand ) );
        }
    } );
};

exports.persist = function( req, res ) {
    dao.persist( req.cookies['AuthSession'], req.body, function( err, body ) {
        if( err ) {
            res.send( 500, JSON.stringify( { error: true } ) );
        } else {
            // update the doc revision
            req.body._rev = body.rev;
            res.send( req.body );
        }
    } );
};

exports.remove = function( req, res ) {
    dao.remove( req.cookies['AuthSession'], req.params.id, req.query.rev, function( err, body ) {
        if( err ) {
            res.send( 500, JSON.stringify( { error: true } ) );
        } else {
            res.send( 200, "OK" );
        }
    } );
};

exports.list = function( req, res ) {
    dao.list( req.cookies['AuthSession'], function( err, list ) {
        if( err ) {
            console.log("error list policies: " + err);
            res.send( 401, JSON.stringify( { error: true } ) );
        } else {
            res.send( list );
        }
    } );
};