var config = {};

config.couchdb = {};
config.twilio = {};

config.couchdb.url = 'http://127.0.0.1:5984/policy';
config.couchdb.secureUrl = 'http://127.0.0.1:5984/policy';
config.couchdb.secondsToInvalidateEvents = 120;
config.couchdb.secondsToFlushVotes = 10;

config.twilio.sid = 'ACxxx';
config.twilio.key = 'yyy';
config.twilio.disableSigCheck = false;

config.cookiesecret = 'jf73Ashs63ALshf840hHvSst2e19506uFYtw3hDta';

module.exports = config;
